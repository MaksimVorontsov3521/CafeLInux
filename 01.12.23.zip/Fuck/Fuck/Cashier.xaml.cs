﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.OleDb;
using System.Configuration;
using System.Collections.Generic;
using System.Data.OleDb;

namespace Fuck
{
    /// <summary>
    /// Логика взаимодействия для Cashier.xaml
    /// </summary>
    public partial class Cashier : Window
    {
        List<string> listOrder = new List<string>();
        private OleDbConnection sqlConnection = null;
        public Cashier(string role)
        {
            InitializeComponent();
            workerIDlabel.Content = role;
            DishesFromMenu DFM = new DishesFromMenu();
            BoxCoffee.ItemsSource = combine(DFM.coffeeName(), DFM.coffeePrice());
        }
        private List<string> combine(List<string> one, List<string> two)
        {
            List<string> combined = new List<string>();
            for (int i = 0; i < one.Count; i++)
            {
                combined.Add(one[i] + " Цена - " + two[i]);
            }
            return combined;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            sqlConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["Sqlcon"].ConnectionString);
            sqlConnection.Open();
        }

        private void BoxCoffee_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            object item = BoxCoffee.SelectedItem;
            Order.Items.Insert(0, item.ToString());
            addtosum(item.ToString());            
        }
        public void addtosum(string item)
        {
            listOrder.Add(item.Remove(7));
            char[] arr;
            arr = item.ToCharArray();
            Array.Reverse(arr);
            Array.Resize(ref arr, 3);
            Array.Reverse(arr);
            item = null;
            for (int i = 0; i < arr.Length; i++)
            {
                item = item+ arr[i].ToString();
            }
            int x = Convert.ToInt32(item);
            
            if (x < 0)
            {
                x = x * -1;
            }
            allsum = allsum + x;
            OrderSum.Content = allsum;
        }
        public int allsum = 0;

        private void CreateOrder_Click(object sender, RoutedEventArgs e)
        {
            using (sqlConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["Sqlcon"].ConnectionString))
            {
                int[] order = new int[6];
                sqlConnection.Open();
                string tableName = "Menu";
                string query;
                string dynamicCondition;
                for (int i = 0; i < listOrder.Count; i++)
                {
                    dynamicCondition = $"Dish Like'{listOrder[i]}'";
                    query = $"SELECT ingredien_1, ingredien_2, ingredien_3, " +
               $"ingredien_4, ingredien_5, ingredien_6 FROM {tableName} WHERE {dynamicCondition}";

                    using (OleDbCommand com = new OleDbCommand(query,sqlConnection))
                    {
                        using (OleDbDataReader reader = com.ExecuteReader())
                        {
                            while(reader.Read())
                            { 
                                string between= reader["ingredien_1"] != DBNull.Value ? reader["ingredien_1"].ToString() : null;
                                order[0] = order[0] + Convert.ToInt32(between);
                                // 2
                                between = reader["ingredien_2"] != DBNull.Value ? reader["ingredien_2"].ToString() : null;
                                order[1] = order[1] + Convert.ToInt32(between);
                                //3
                                between = reader["ingredien_3"] != DBNull.Value ? reader["ingredien_3"].ToString() : null;
                                order[2] = order[2] + Convert.ToInt32(between);
                                //4
                                between = reader["ingredien_4"] != DBNull.Value ? reader["ingredien_4"].ToString() : null;
                                order[3] = order[3] + Convert.ToInt32(between);
                                //5
                                between = reader["ingredien_5"] != DBNull.Value ? reader["ingredien_5"].ToString() : null;
                                order[4] = order[4] + Convert.ToInt32(between);
                                //6
                                between = reader["ingredien_6"] != DBNull.Value ? reader["ingredien_6"].ToString() : null;
                                order[5] = order[5] + Convert.ToInt32(between);
                            }
                        }
                    }
                }
                sqlConnection.Close();
                RemoveFromVan(order);
            }
        }
        private void RemoveFromVan(int[] order)
        {
            using (sqlConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["Sqlcon"].ConnectionString))
            {
                int[] van = new int[6];
                sqlConnection.Open();
                string query = $"SELECT ingredien_1, ingredien_2, ingredien_3, " +
               $"ingredien_4, ingredien_5, ingredien_6 FROM Van WHERE Account_van={Convert.ToInt32(workerIDlabel.Content)} ";
                using (OleDbCommand com = new OleDbCommand(query, sqlConnection))
                {
                    using (OleDbDataReader reader = com.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string between = reader["ingredien_1"] != DBNull.Value ? reader["ingredien_1"].ToString() : null;
                            van[0] = van[0] + Convert.ToInt32(between);
                            // 2
                            between = reader["ingredien_2"] != DBNull.Value ? reader["ingredien_2"].ToString() : null;
                            van[1] = van[1] + Convert.ToInt32(between);
                            //3
                            between = reader["ingredien_3"] != DBNull.Value ? reader["ingredien_3"].ToString() : null;
                            van[2] = van[2] + Convert.ToInt32(between);
                            //4
                            between = reader["ingredien_4"] != DBNull.Value ? reader["ingredien_4"].ToString() : null;
                            van[3] = van[3] + Convert.ToInt32(between);
                            //5
                            between = reader["ingredien_5"] != DBNull.Value ? reader["ingredien_5"].ToString() : null;
                            van[4] = van[4] + Convert.ToInt32(between);
                            //6
                            between = reader["ingredien_6"] != DBNull.Value ? reader["ingredien_6"].ToString() : null;
                            van[5] = van[5] + Convert.ToInt32(between);
                        }
                    }
                }
                sqlConnection.Close();
                UpDate(order,van);
            }
        }
        private void UpDate(int[]order,int[]van)
        {
            using (sqlConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["Sqlcon"].ConnectionString))
            {
                int Id = Convert.ToInt32(workerIDlabel.Content);
                sqlConnection.Open();
                string query = $"UPDATE Van SET " +
                     $"ingredien_1 = {van[0] - order[0]}, " +
                     $"ingredien_2 = {van[1] - order[1]}, " +
                     $"ingredien_3 = {van[2] - order[2]}, " +
                     $"ingredien_4 = {van[3] - order[3]}, " +
                     $"ingredien_5 = {van[4] - order[4]}, " +
                     $"ingredien_6 = {van[5] - order[5]} " +  
                $"WHERE Account_van = {Id}";
                OleDbCommand com = new OleDbCommand(query, sqlConnection);
                com.ExecuteNonQuery();
                sqlConnection.Close();
            }

        }
    }
}
