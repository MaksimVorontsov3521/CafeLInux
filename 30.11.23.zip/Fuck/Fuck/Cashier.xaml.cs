﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.OleDb;
using System.Configuration;
using System.Collections.Generic;
using System.Data.OleDb;

namespace Fuck
{
    /// <summary>
    /// Логика взаимодействия для Cashier.xaml
    /// </summary>
    public partial class Cashier : Window
    {
        List<string> listOrder = new List<string>();
        private OleDbConnection sqlConnection = null;
        public Cashier(string role)
        {
            InitializeComponent();
            workerIDlabel.Content = role;
            BoxCoffee.ItemsSource = combine(coffeeName(), coffeePrice());
        }
        private List<string> combine(List<string> one, List<string> two)
        {
            List<string> combined = new List<string>();
            for (int i = 0; i < one.Count; i++)
            {
                combined.Add(one[i] + " Цена - " + two[i]);
            }
            return combined;
        }


        private List<string> coffeeName()
        {
            string something = "Dish";
            using (sqlConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["Sqlcon"].ConnectionString))
            {
                sqlConnection.Open();

                using (OleDbCommand com = new OleDbCommand("Select Dish From Menu where Dish Like 'Coffee%'", sqlConnection))
                {
                    using (OleDbDataReader reader = com.ExecuteReader())
                    {
                        List<string> values = new List<string>();
                        while (reader.Read())
                        {
                            string value = reader[something] != DBNull.Value ? reader[something].ToString() : null;
                            values.Add(value);
                        }
                        return values;
                    }
                }
            }
        }

        private List<string> coffeePrice()
        {
            string something = "Price";
            using (sqlConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["Sqlcon"].ConnectionString))
            {
                sqlConnection.Open();

                using (OleDbCommand com = new OleDbCommand("Select Price From Menu where Dish Like 'Coffee%'", sqlConnection))
                {
                    using (OleDbDataReader reader = com.ExecuteReader())
                    {
                        List<string> values = new List<string>();
                        while (reader.Read())
                        {
                            string value = reader[something] != DBNull.Value ? reader[something].ToString() : null;
                            values.Add(value);
                        }
                        return values;
                    }
                }
            }
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            sqlConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["Sqlcon"].ConnectionString);
            sqlConnection.Open();
        }

        private void BoxCoffee_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            object item = BoxCoffee.SelectedItem;
            Order.Items.Insert(0, item.ToString());
            addtosum(item.ToString());            
        }
        public void addtosum(string item)
        {
            listOrder.Add(item.Remove(7));
            char[] arr;
            arr = item.ToCharArray();
            Array.Reverse(arr);
            Array.Resize(ref arr, 3);
            Array.Reverse(arr);
            item = null;
            for (int i = 0; i < arr.Length; i++)
            {
                item = item+ arr[i].ToString();
            }
            int x = Convert.ToInt32(item);
            
            if (x < 0)
            {
                x = x * -1;
            }
            allsum = allsum + x;
            OrderSum.Content = allsum;
        }
        public int allsum = 0;

        private void CreateOrder_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < listOrder.Count; i++)
            {
                OleDbCommand com = new OleDbCommand("Select Dish From Menu Where Dish Like '%@item'", sqlConnection);
            }
        }
    }
}
