﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

namespace Fuck
{
    /// <summary>
    /// Логика взаимодействия для Storage.xaml
    /// </summary>
    public partial class Storage : Window
    {
        List<string> listOrder = new List<string>();
        private OleDbConnection sqlConnection = null;
        public Storage(string role)
        {
            InitializeComponent();
            workerIDlabel.Content = role;
            ListOfVans.ItemsSource = CreateAList();
        }

        private void Apply_Click(object sender, RoutedEventArgs e)
        {
            using (sqlConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["Sqlcon"].ConnectionString))
            {
                int Id = Convert.ToInt32(Van_id.Content);
                sqlConnection.Open();
                string query = $"UPDATE Van SET " +
                     $"ingredien_1 = {vanproducts[0] + Convert.ToInt32(TB1.Text)}, " +
                     $"ingredien_2 = {vanproducts[1] + Convert.ToInt32(TB2.Text)}, " +
                     $"ingredien_3 = {vanproducts[2] + Convert.ToInt32(TB3.Text)}, " +
                     $"ingredien_4 = {vanproducts[3] + Convert.ToInt32(TB4.Text)}, " +
                     $"ingredien_5 = {vanproducts[4] + Convert.ToInt32(TB5.Text)}, " +
                     $"ingredien_6 = {vanproducts[5] + Convert.ToInt32(TB6.Text)} " +
                $"WHERE Account_van = {Id}";
                OleDbCommand com = new OleDbCommand(query, sqlConnection);
                com.ExecuteNonQuery();
                sqlConnection.Close();
            }

        }
        private List<string> CreateAList()
        {
            string something = "Id_van";
            using (sqlConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["Sqlcon"].ConnectionString))
            {
                sqlConnection.Open();

                using (OleDbCommand com = new OleDbCommand("Select Id_van From Van", sqlConnection))
                {
                    using (OleDbDataReader reader = com.ExecuteReader())
                    {
                        List<string> values = new List<string>();
                        while (reader.Read())
                        {
                            string value = reader[something] != DBNull.Value ? reader[something].ToString() : null;
                            values.Add(value);
                        }
                        sqlConnection.Close();
                        return values;
                    }
                }
            }
        }
        private void MakeAnUpdate()
        {
            using (sqlConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["Sqlcon"].ConnectionString))
            {
                int[] van = new int[6];
                sqlConnection.Open();
                string query = $"SELECT ingredien_1, ingredien_2, ingredien_3, " +
               $"ingredien_4, ingredien_5, ingredien_6 FROM Van WHERE Account_van={Convert.ToInt32(Van_id.Content)} ";
                using (OleDbCommand com = new OleDbCommand(query, sqlConnection))
                {
                    using (OleDbDataReader reader = com.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string between = reader["ingredien_1"] != DBNull.Value ? reader["ingredien_1"].ToString() : null;
                            van[0] = van[0] + Convert.ToInt32(between);
                            // 2
                            between = reader["ingredien_2"] != DBNull.Value ? reader["ingredien_2"].ToString() : null;
                            van[1] = van[1] + Convert.ToInt32(between);
                            //3
                            between = reader["ingredien_3"] != DBNull.Value ? reader["ingredien_3"].ToString() : null;
                            van[2] = van[2] + Convert.ToInt32(between);
                            //4
                            between = reader["ingredien_4"] != DBNull.Value ? reader["ingredien_4"].ToString() : null;
                            van[3] = van[3] + Convert.ToInt32(between);
                            //5
                            between = reader["ingredien_5"] != DBNull.Value ? reader["ingredien_5"].ToString() : null;
                            van[4] = van[4] + Convert.ToInt32(between);
                            //6
                            between = reader["ingredien_6"] != DBNull.Value ? reader["ingredien_6"].ToString() : null;
                            van[5] = van[5] + Convert.ToInt32(between);
                        }
                    }
                }
                for (int i = 0; i < 6; i++)
                {
                    vanproducts[i] = van[i];
                }
                sqlConnection.Close();
                FillTexBoxs(van);
            }
        }
        public int[] vanproducts = new int[6];
        private void FillTexBoxs(int[] van)
        {
            int[] order = new int[6];
            for (int i=0;i<6;i++)
            {
                order[i] = 100 - van[i];
            }
            TB1.Text = Convert.ToString(order[0]);
            TB2.Text = Convert.ToString(order[1]);
            TB3.Text = Convert.ToString(order[2]);
            TB4.Text = Convert.ToString(order[3]);
            TB5.Text = Convert.ToString(order[4]);
            TB6.Text = Convert.ToString(order[5]);

           
           
        }
        private void ListOfVans_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Van_id.Content = ListOfVans.SelectedItem.ToString();
            MakeAnUpdate();
        }
    }
}
