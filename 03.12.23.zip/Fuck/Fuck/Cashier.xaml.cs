﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.OleDb;
using System.Windows;
using System.Windows.Controls;

namespace Fuck
{
    /// <summary>
    /// Логика взаимодействия для Cashier.xaml
    /// </summary>
    public partial class Cashier : Window
    {
        List<string> listOrder = new List<string>();
        private OleDbConnection sqlConnection = null;
        DishesFromMenu DFM = new DishesFromMenu();
        public string ingrediance;
        public string[] ingmass;
        public Cashier(string role)
        {
            InitializeComponent();
            workerIDlabel.Content = role;
            Orders.Show();
            ingrediance = DFM.Ingrediance(DFM.COLUMN_NAME("Menu"));
            ingmass = ingrediance.Split(',');

            BoxCoffee.ItemsSource = combine(DFM.coffeeName(), DFM.coffeePrice());
        }
        private List<string> combine(List<string> one, List<string> two)
        {
            List<string> combined = new List<string>();
            for (int i = 0; i < one.Count; i++)
            {
                combined.Add(one[i] + " Цена - " + two[i]);
            }
            return combined;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            sqlConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["Sqlcon"].ConnectionString);
            sqlConnection.Open();

        }
        private void BoxCoffee_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            object item = BoxCoffee.SelectedItem;
            Order.Items.Insert(0, item.ToString());
            addtosum(item.ToString());
        }
        public void addtosum(string item)
        {
            listOrder.Add(item.Remove(12));
            char[] arr;
            arr = item.ToCharArray();
            Array.Reverse(arr);
            Array.Resize(ref arr, 3);
            Array.Reverse(arr);
            item = null;
            for (int i = 0; i < arr.Length; i++)
            {
                item = item + arr[i].ToString();
            }
            int x = Convert.ToInt32(item);

            if (x < 0)
            {
                x = x * -1;
            }
            allsum = allsum + x;
            OrderSum.Content = allsum;
        }
        public int allsum = 0;

        private void CreateOrder_Click(object sender, RoutedEventArgs e)
        {
            int[] order = new int[ingmass.Length];
            string query;
            string dynamicCondition;
            string between = "";
            for (int i = 0; i < listOrder.Count; i++)
            {
                dynamicCondition = $"Dish Like'%{listOrder[i]}%'";
                query = $"SELECT {ingrediance} FROM Menu WHERE {dynamicCondition}";

                using (OleDbCommand com = new OleDbCommand(query, sqlConnection))
                {
                    using (OleDbDataReader reader = com.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            for (int j = 0; j < ingmass.Length; j++)
                            {
                                between = reader[$"{ingmass[j]}"] != DBNull.Value ? reader[$"{ingmass[j]}"].ToString() : null;
                                order[j] = order[j] + Convert.ToInt32(between);
                            }
                        }
                    }
                }
            }
            RemoveFromVan(order);
        }
        private void RemoveFromVan(int[] order)
        {
            int count = 0;
            int[] van = new int[ingmass.Length];
            string between = "";
            string query = $"SELECT {ingrediance},GGhter FROM Van WHERE Account_van={Convert.ToInt32(workerIDlabel.Content)} ";
            using (OleDbCommand com = new OleDbCommand(query, sqlConnection))
            {
                using (OleDbDataReader reader = com.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        for (int j = 0; j < ingmass.Length; j++)
                        {
                            between = reader[$"{ingmass[j]}"] != DBNull.Value ? reader[$"{ingmass[j]}"].ToString() : null;
                            van[j] = van[j] + Convert.ToInt32(between);
                        }
                        between = reader[$"GGhter"] != DBNull.Value ? reader[$"GGhter"].ToString() : null;
                        count = count + Convert.ToInt32(between);
                    }
                }
            }

            UpDate(order, van, count);

        }
        Orders Orders = new Orders();
        private void UpDate(int[] order, int[] van, int count)
        {
            count++;
            string ing = "";
            for (int i = 0; i < ingmass.Length; i++)
            {
                ing = ing + $"{ingmass[i]}={van[i] - order[i]}" + ",";
            }
            int Id = Convert.ToInt32(workerIDlabel.Content);
            string query = $"UPDATE Van SET {ing} GGhter={count} WHERE Account_van = {Id}";
            OleDbCommand com = new OleDbCommand(query, sqlConnection);
            com.ExecuteNonQuery();
            Orders.NewItem(listOrder, OrderSum.Content.ToString(), count);
            listOrder.Clear();
            Order.Items.Clear();
            OrderSum.Content = "0";
            allsum = 0;
        }
    }
}
