﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Configuration;


namespace Fuck
{
    class DishesFromMenu
    {
        private OleDbConnection sqlConnection = null;
        public DishesFromMenu()
        {
            sqlConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["Sqlcon"].ConnectionString);
            sqlConnection.Open();
        }

        public List<string> coffeePrice()
        {
            string something = "Price";
            using (sqlConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["Sqlcon"].ConnectionString))
            {
                sqlConnection.Open();

                using (OleDbCommand com = new OleDbCommand("Select Price From Menu where Dish Like 'Coffee%'", sqlConnection))
                {
                    using (OleDbDataReader reader = com.ExecuteReader())
                    {
                        List<string> values = new List<string>();
                        while (reader.Read())
                        {
                            string value = reader[something] != DBNull.Value ? reader[something].ToString() : null;
                            values.Add(value);
                        }
                        sqlConnection.Close();
                        return values;
                    }
                }          
            }
        }
        public List<string> coffeeName()
        {
            string something = "Dish";
            using (sqlConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["Sqlcon"].ConnectionString))
            {
                sqlConnection.Open();

                using (OleDbCommand com = new OleDbCommand("Select Dish From Menu where Dish Like 'Coffee%'", sqlConnection))
                {
                    using (OleDbDataReader reader = com.ExecuteReader())
                    {
                        List<string> values = new List<string>();
                        while (reader.Read())
                        {
                            string value = reader[something] != DBNull.Value ? reader[something].ToString() : null;
                            values.Add(value);
                        }
                        sqlConnection.Close();
                        return values;
                    }
                }
            }
        }

    }
}
